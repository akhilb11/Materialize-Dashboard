<!DOCTYPE html>
<html lang="en">
    <head>
		<meta name="viewport" content="initial-scale=1.0, user-scalable=yes, width=device-width" />
    </head>
      
  <body>
    <div class="container">
      <div style="margin-top:20px" class="page-header" id="banner">
		<?php 
		$file = file("/private/var/log/apache2/access_log");
		for ($i = count($file)-500; $i < count($file); $i++) {
		 echo nl2br($file[$i]);
		}
		?>
      <div>
      <div style="margin-top:20px">
      </div>
     </div>
  </body>
</html>