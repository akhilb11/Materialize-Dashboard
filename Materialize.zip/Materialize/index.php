<?php
$Android = stripos($_SERVER['HTTP_USER_AGENT'],"Android");

if( $Android ){
	header('Location:./index2.html');
}
else { 
	header('Location:./error.html');
}

?>

<!DOCTYPE html>
<html>

<head>
</head>
<body>
</body>

</html>